<div align="center">

## Termux WhatsApp Bot 

A Lightweight WhatApp Bot Without Headless Browser

<img src="https://www.pngkey.com/png/full/824-8245235_if-you-just-want-crazy-anime.png" width="300" >


![Twitter](https://img.shields.io/twitter/follow/fdciabdul?style=flat-square)
![Fork](https://img.shields.io/github/forks/fdciabdul/termux-whatsapp-bot?style=flat-square)

 Join discord for new information , or talk to me https://discord.gg/j3mu7fxweq

## Installation


# Termux
```bash
> git clone https://github.com/fdciabdul/termux-whatsapp-bot
> cd termux-whatsapp-bot
> bash install.sh

```

# Linux ( debian & ubuntu )
```bash
> git clone https://github.com/fdciabdul/termux-whatsapp-bot
> cd termux-whatsapp-bot
> bash install.sh

```

# Windows

Clone the project and run 



### Usage
1. run the Whatsapp bot

```bash
> node index.js
```

after running it you need to scan the qr


## features 

```bash
> Sticker 

> Nama 

> Nulis

> Random pantun

> Penyegar Timeline

> Youtube Downloader

> Youtube MP3
```

more features was coming soon
